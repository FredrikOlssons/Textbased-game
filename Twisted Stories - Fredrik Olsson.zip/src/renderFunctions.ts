import {Gamestep}

export const rederGamestep: (gamestep: Gamestep) => void = (gamestep) => {

}